import wave
from cmu_112_graphics import * #taken from course website
from tkinter import *
from PIL import Image
import math
from GameMode import *
from SplashScreenMode import *
from TutorialMode import *
from AubioBeatDetection import *

class GameOverMode(Mode):
    def appStarted(mode):
        mode.highScore=max(mode.app.score+len(mode.app.platformsCrossed),\
            mode.app.highScore)
        print(mode.app.score)
        mode.updateHighScore()
    def updateHighScore(mode):
        mode.app.highScore=mode.highScore
    def keyPressed(mode, event):
        mode.app.gameMode=GameMode()
        mode.app.tutorialMode=TutorialMode()
        if event.key=="Space":
            if not isinstance(mode.app.tutorialCompleted, bool):
                mode.app.score=0
                mode.app.platformsCrossed=[]
                mode.app.gameWon=False
                mode.app.setActiveMode(mode.app.gameMode)
            else:
                mode.app.tutorialCompleted=False
                mode.app.setActiveMode(mode.app.tutorialMode)
        if event.key=="r":
            mode.app.tutorialCompleted=None
            mode.app.gameWon=False
            mode.app.score=0
            mode.app.platformsCrossed=[]
            mode.app.setActiveMode(mode.app.splashScreenMode)
            
    def redrawAll(mode, canvas):
        if mode.app.gameWon==True:
            canvas.create_rectangle(0,0, mode.width, mode.height, fill="cyan")
            canvas.create_text(mode.width/2, mode.height/5, text="Superb!", \
                font=f'modern {int(mode.width/10)} bold italic')
            canvas.create_text(mode.width/6, mode.height*3/7, \
                text=f'Your Score: {mode.app.score}', anchor="w",\
                    font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/6, mode.height*4/7, \
                text=f'Bonus: {len(mode.app.platformsCrossed)}', anchor="w",\
                    font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/6, mode.height*5/7, anchor="w",\
            text=f'Your total: {mode.app.score+len(mode.app.platformsCrossed)}',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/6, mode.height*6/7, anchor="w",\
            text=f'High Score: {mode.app.highScore}',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/2+mode.width/6, mode.height*3/7, \
                anchor="w", \
                    text='''
        Press Space to 
            Play Again
                        ''',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/2+mode.width/6, mode.height*5/7, \
                anchor="w", \
                    text='''
        Press R to return
        to Main Screen
                        ''',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
        elif mode.app.tutorialCompleted==None:
            canvas.create_rectangle(0,0, mode.width, mode.height, \
                fill="violetred")
            canvas.create_text(mode.width/2, mode.height/4, text="A Nice Try",\
            font=f'Bahnschrift {int(mode.width/10)} bold italic',fill="white")
            canvas.create_text(mode.width/6, mode.height*3/7, anchor="w",\
                text=f'Your Score: {mode.app.score}', \
                    font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/6, mode.height*4/7, anchor="w",\
                text=f'Bonus: {len(mode.app.platformsCrossed)}', fill="white",\
                    font=f"Bahnschrift {int(mode.width/40)}")
            canvas.create_text(mode.width/6, mode.height*5/7, anchor="w",\
            text=f'Your total: {mode.app.score+len(mode.app.platformsCrossed)}',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/6, mode.height*6/7, anchor="w",\
            text=f'High Score: {mode.app.highScore}',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/2, mode.height*3/7, anchor="w", \
                    text='''
            Press Space to 
                Play Again
                        ''',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
            canvas.create_text(mode.width/2, mode.height*5/7, anchor="w", \
                    text='''
            Press R to return
            to Main Screen
                        ''',\
                font=f"Bahnschrift {int(mode.width/40)}", fill="white")
        elif mode.app.tutorialCompleted==False:
            canvas.create_rectangle(0,0, mode.width, mode.height, \
                fill="violetred")
            canvas.create_text(mode.width/2, mode.height/4, text="A Nice Try",\
                font=f'modern {int(mode.width/10)} bold italic',fill="white")
            canvas.create_text(mode.width/2, mode.height/2, fill="white", \
                text="Press Space to try again", \
                    font=f'Bahnschrift {int(mode.width/20)}')
            canvas.create_text(mode.width/2, mode.height*2/3, fill="white", \
                text="Press R to Return to the Main Screen", \
                    font=f'Bahnschrift {int(mode.width/40)}')
        