import wave
from cmu_112_graphics import * #Taken from course website
#http://www.cs.cmu.edu/~112/notes/cmu_112_graphics.py
from tkinter import *
from PIL import Image
import math, random
import pygame

pygame.init()
class TutorialMode(Mode):
    def appStarted(mode):
        mode.runImage=mode.loadImage("Running Sprite Sheet.png")
        mode.runSprites=mode.packSprite(mode.runImage,4)
        mode.duckImage=mode.loadImage("Ducking Sprite.png")
        mode.duckSprites=mode.packSprite(mode.duckImage, 1)
        mode.jumpImage=mode.loadImage("Jumping Sprite Sheet.png")
        mode.jumpSprites=mode.packSprite(mode.jumpImage, 2)
        mode.player=Player(0,0,20, mode.runSprites, mode.duckSprites,\
             mode.jumpSprites, mode)
        mode.runCounter=0
        mode.deathCounter=0
        mode.vanishingpoint=mode.height/3 #Arbitrary reference pt:2.5d graphics
        mode.gameOver=False
        if mode.app.tutorialCompleted==None:
            mode.app.tutorialCompleted=False
        mode.timer=0 #Tells how long to duck for
        mode.landBlocks=dict()
        mode.app.platformsCrossed=[] #tell you want to highlight next
        mode.obstacles=dict()
        mode.message=""
        mode.vi=70
        mode.g=10
        mode.speed=15
        mode.i=1
        mode.timeInAir=2*mode.vi/mode.g
        mode.generateTerrain()
    def generateTerrain(mode): #accounts for edge cases #Hardcoded map
        StartingBlock(-50, 50, 0, 300, mode.landBlocks, 0)
        landMass(-50, 50, 300, 500, mode.landBlocks, 1)
        for i in range(2, 5):
            mode.generate0Map(i)
        mode.generate1Map(5)
        mode.generate1Map(6)
        for i in range(7, 10):
            mode.generate0Map(i)
        mode.generate2Map(10)
        for i in range(11, 13):
            mode.generate0Map(i)
        mode.generate3Map(13)
        for i in range(14, 18):
            mode.generate0Map(i)
        mode.generate3Map(18)
        mode.generate2Map(19)
        mode.generate3Map(20)
        mode.generate2Map(21)
        for i in range(22, 25):
            mode.generate0Map(i)
        mode.generateObstacles(1, 25)
        for i in range(26, 30):
            mode.generate0Map(i)
        mode.generateEndPiece()
    def generateEndPiece(mode): #The last piece goes straight with a cap in btw
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
                olderBlock.y1
        if width<height: #if it is a straight block #1/3 is arbitrary
            if (y1<block.y1):
                mode.landBlocks[key+1]=EndingBlock(block.x0, block.x1, \
                    block.y1+1/2*mode.timeInAir*mode.speed, block.y1+\
                    10*mode.speed*5+1/2*mode.timeInAir\
                    *mode.speed, mode.landBlocks,key+1)
                    #mode.timeInAir*mode.speed=distance traveled while jumping
            elif (y1>block.y1):
                mode.landBlocks[key+1]=EndingBlock(block.x0, block.x1, \
                    block.y0-1/2*mode.timeInAir*mode.speed-\
                        10*mode.speed*5, block.y0\
                    -1/2*mode.timeInAir*mode.speed, mode.landBlocks,key+1)
        elif width>height:
            if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                #105 being the safe distance when jumping
                mode.landBlocks[key+1]=EndingBlock(block.x1+\
                    (1/2)*mode.timeInAir*mode.speed, block.x1+\
                    10*mode.speed*5+\
                    (1/2)*mode.timeInAir*mode.speed, block.y0, block.y1, \
                    mode.landBlocks, key+1)
            elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                mode.landBlocks[key+1]=EndingBlock(block.x0-10\
                    *mode.speed*5-(1/2)*mode.timeInAir*mode.speed,\
                        block.x0-(1/2)*mode.timeInAir*mode.speed, block.y0, \
                        block.y1, mode.landBlocks, key+1)
    def generate3Map(mode, beat): #Generates a right piece
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
            olderBlock.y1
        if width<height: #if it is a straight block
            if (y1<block.y1):
                mode.landBlocks[key+1]=landMass(block.x1, block.x1+\
                (3)*mode.speed*5, block.y1-width, block.y1, mode.landBlocks, key+1)
        elif width>height: #if it is a sideways block
            if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                #105 being the safe distance when jumping
                mode.landBlocks[key+1]=landMass(block.x1-height, block.x1,\
                     block.y0-(3)*mode.speed*5, block.y0, \
                    mode.landBlocks, key+1)
            elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                mode.landBlocks[key+1]=landMass(block.x0, block.x0+height, \
                    block.y1, block.y1+(3)*mode.speed*5, \
                        mode.landBlocks, key+1)
    def generate2Map(mode, beat):
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
                olderBlock.y1
        if width<height: #if it is a straight block
            if (y1<block.y1):
                mode.landBlocks[key+1]=landMass(block.x0-(3)*mode.speed*5, \
                    block.x0, block.y1-width, block.y1, mode.landBlocks, key+1)
        elif width>height:
            if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                #Eliminating floating point errors
                #105 being the safe distance when jumping
                mode.landBlocks[key+1]=landMass(block.x1-height, block.x1,\
                    block.y1, block.y1+(3)*mode.speed*5, mode.landBlocks, key+1)
            elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                mode.landBlocks[key+1]=landMass(block.x0, block.x0+height, \
                    block.y0-(3)*mode.speed*5, block.y0, mode.landBlocks, key+1)
    def generate1Map(mode, beat):
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
                olderBlock.y1
        if width<height: #if it is a straight block #1/3 is arbitrary
            if (y1<block.y1):
                mode.landBlocks[key+1]=landMass(block.x0, block.x1, \
                    block.y1+1/2*mode.timeInAir*mode.speed, block.y1+\
                    (3)*mode.speed*5+1/2*mode.timeInAir\
                    *mode.speed, mode.landBlocks,key+1)
                    #mode.timeInAir*mode.speed=distance traveled while jumping
        elif width>height:
            if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                #105 being the safe distance when jumping
                mode.landBlocks[key+1]=landMass(block.x1+\
                    (1/2)*mode.timeInAir*mode.speed, block.x1+(3)*mode.speed*5+\
                    (1/2)*mode.timeInAir*mode.speed, block.y0, block.y1, \
                    mode.landBlocks, key+1)
            elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                mode.landBlocks[key+1]=landMass(block.x0-(3)*mode.speed*5-\
                    (1/2)*mode.timeInAir*mode.speed,block.x0-(1/2)*\
                        mode.timeInAir*mode.speed, block.y0, block.y1, \
                            mode.landBlocks, key+1)
    def generate0Map(mode, beat):
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
                olderBlock.y1
        if width<height: #if it is a straight block #1/3 is arbitrary
            if (y1<block.y1):
                mode.landBlocks[key+1]=landMass(block.x0, block.x1, \
                block.y1,block.y1+(3)*mode.speed*5,\
                    mode.landBlocks,key+1)
        elif width>height:
            if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                mode.landBlocks[key+1]=landMass(block.x1, block.x1+\
                (3)*mode.speed*5, block.y0, block.y1, mode.landBlocks, key+1)
            elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                mode.landBlocks[key+1]=landMass(block.x0-(3)*mode.speed*5,\
                    block.x0, block.y0, block.y1, mode.landBlocks, key+1)
    def generateObstacles(mode, code, beat):
        key=len(mode.landBlocks)-1
        block=mode.landBlocks[key]
        width=abs(block.x1-block.x0)
        height=abs(block.y1-block.y0)
        olderKey=len(mode.landBlocks)-2
        olderBlock=mode.landBlocks[olderKey]
        x0, x1, y0, y1=olderBlock.x0, olderBlock.x1, olderBlock.y0,\
                olderBlock.y1
        if code==1:
            if height>width:
                Spikes((block.x0+block.x1)/2, block.y1, 55, mode, "front", \
                    key+1, mode.obstacles)
            elif width>height:
                if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                    Spikes(block.x1,(block.y0+block.y1)/2, 55,mode, "side", \
                        key+1, mode.obstacles)
                elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                    Spikes(block.x0, (block.y0+block.y1)/2, 55, mode, "side",\
                         key+1, mode.obstacles)
        elif code==3:
            if height>width:
                LaserGrid((block.x0+block.x1)/2, block.y1, 0, mode, "front", \
                    key+1, mode.obstacles)
            elif width>height:
                if int(block.x0-x1)==0 or int((block.x0-105-x1)/10)==0:
                    LaserGrid(block.x1,(block.y0+block.y1)/2, 0,mode, "side", \
                        key+1, mode.obstacles)
                elif int(block.x1-x0)==0 or int((block.x1+105-x0)/10)==0:
                    LaserGrid(block.x0, (block.y0+block.y1)/2, 0, mode, "side",\
                         key+1, mode.obstacles)
    def packSprite(mode, image, frames):
        spriteList=[]
        width, height=image.size
        hr=220/height #Music Theory jokes
        scale=mode.scaleImage(image, hr) #Scales the image to be 220 pxls
        w, h=scale.size
        for i in range(frames):
            sprite=scale.crop((i*w/frames, 0, (i+1)*w/frames, h))
            spriteList+=[sprite] #Puts spritesheet into list
        return spriteList
    def keyPressed(mode, event):
        if mode.gameOver==False:
            if event.key=="Space":
                mode.player.jump(0, mode.g, mode.vi) #Does physics on player
            elif event.key=="a":
                mode.aKeyPressed()
            elif event.key=="d":
                mode.dKeyPressed()
            elif event.key=="s":
                if mode.player.mode!="jump":
                    mode.player.duck()
            elif event.key=="h":
                mode.player.turnLeft(mode)
            elif event.key=="l":
                mode.player.turnRight(mode)
    def aKeyPressed(mode):
        if mode.player.dir==0:
            mode.player.x-=5
        elif mode.player.dir==1:
            mode.player.y-=5
        elif mode.player.dir==2:
            mode.player.x+=5
        elif mode.player.dir==3:
            mode.player.y+=5
        mode.player.apparentX-=5
        mode.player.renderX-=5
    def dKeyPressed(mode):
        if mode.player.dir==0:
            mode.player.x+=5
        elif mode.player.dir==1:
            mode.player.y+=5
        elif mode.player.dir==2:
            mode.player.x-=5
        elif mode.player.dir==3:
            mode.player.y-=5
        mode.player.apparentX+=5
        mode.player.renderX+=5
    def clearObstacles(mode): #Checks if clears obstacles based on location, etc
        if len(mode.obstacles)==0:
            return True
        for key in mode.obstacles:
            obstacle=mode.obstacles[key]
            if obstacle.x0<mode.player.x<obstacle.x1 and \
                obstacle.y0<mode.player.y<obstacle.y1 and \
                    obstacle.cz<=mode.player.z<=obstacle.cz+obstacle.height:
                return obstacle
            if obstacle.x0<mode.player.x<obstacle.x1 and \
                obstacle.y0<mode.player.y<obstacle.y1 and \
                    obstacle.cz<=mode.player.z+mode.player.height\
                        <=obstacle.cz+obstacle.height:
                return True
        return True
    def timerFired(mode):
        if mode.gameOver==False:
            mode.movePlayer() #Increments by steady run speed
            mode.runCounter+=1 #Loops through sprite
            if mode.clearObstacles()!=True:
                mode.gameOver=True
            mode.passObstacles()
            if mode.player.z<=20 and mode.isOnTop()==False:#Accounts for edge cs
                mode.player.supported=False
                mode.gameOver=True
            if mode.isOnTop()!= False:
                mode.modifyMessages()
            if mode.player.mode=="duck": 
                mode.player.z=20
                mode.timer+=1
                if mode.timer%30==0:
                    mode.player.mode="run"
                    mode.player.width, mode.player.height, mode.player.depth=\
                        mode.player.runWidth, mode.player.runHeight,\
                             mode.player.runDepth
            elif mode.player.mode=="jump":
                mode.player.upv-=mode.g
                mode.player.z+=mode.player.upv
                if mode.player.z<=20:
                    mode.player.mode="run"
                    mode.player.upv=0
            elif mode.player.z<20:
                #If the player's y falls inside the map's y, we know that 
                #the player is on solid ground, so we can change the is 
                #supported to True.
                if mode.isOnTop()!=False:
                    mode.player.supported=True
                    mode.player.mode="run"
                    mode.player.z=20
                    mode.player.upv=0
            else: 
                if mode.isOnTop()!=False:
                    mode.player.supported=True
                    mode.player.mode="run"
        if mode.gameOver==True:
            mode.deathCounter+=1
            mode.app.setActiveMode(mode.app.gameOverMode)
    def modifyMessages(mode):
        if mode.isOnTop().key==3:
            mode.message="Press Space To Jump"
        elif mode.isOnTop().key==4 or mode.isOnTop().key==5:
            mode.message="Jump!"
        elif mode.isOnTop().key==6:
            mode.message="Excellent!"
        elif mode.isOnTop().key==8:
            mode.message="Press H to turn left"
        elif mode.isOnTop().key==9 and mode.isOnTop().apparentY0<=\
            mode.player.apparentY:
            mode.message="Left!"
        elif mode.isOnTop().key==10:
            mode.message=="You're Doing Great!"
        elif mode.isOnTop().key==11:
            mode.message="Press L to turn right"
        elif mode.isOnTop().key==12:
            mode.message="Right!"
        elif mode.isOnTop().key==13:
            mode.message="""
    Press A and D to Shift 
        Left and Right!
            """
        elif mode.isOnTop().key==23:
            mode.message="Press S to Duck!"
        elif isinstance(mode.isOnTop(), EndingBlock):
            mode.message=\
                """
    You are Ready! 
       Good Luck!
            """
        else: mode.message=""
    def movePlayer(mode):
        if mode.player.dir==0:
            mode.player.y+=mode.speed
            mode.player.apparentY+=mode.speed
        elif mode.player.dir==1:
            mode.player.x-=mode.speed#Since apparent X and Y are switched
            mode.player.apparentY+=mode.speed
        elif mode.player.dir==2:
            mode.player.y-=mode.speed
            mode.player.apparentY+=mode.speed
        elif mode.player.dir==3:
            mode.player.x+=mode.speed
            mode.player.apparentY+=mode.speed
    def passObstacles(mode):
        for key in mode.obstacles:
            obstacle=mode.obstacles[key]
            if obstacle.cleared==False:
                if obstacle.x0<mode.player.x<obstacle.x1 and obstacle.y0<\
                    mode.player.y<obstacle.y1:
                    obstacle.cleared=True
    def isOnTop(mode):
        for key in range(len(mode.landBlocks)): #Checks if player is supported
            block=mode.landBlocks[key]
            if block.onTop(mode):
                if isinstance(block, EndingBlock):
                    mode.app.tutorialCompleted=True
                    return block
                if key==len(mode.app.platformsCrossed):
                    mode.turnOffInverse()
                    nextBlock=mode.landBlocks[key+1]
                    nextBlock.fill=nextBlock.inverse
                    mode.app.platformsCrossed+=[key]
                return block
        return False
    def turnOffInverse(mode):
        for key in range(len(mode.landBlocks)):
            if isinstance(mode.landBlocks[key], landMass) and not \
                isinstance(mode.landBlocks[key], StartingBlock) and not \
                isinstance(mode.landBlocks[key], EndingBlock):
                mode.landBlocks[key].fill=mode.landBlocks[key].color
    def redrawAll(mode, canvas):
        for i in range(0,40, 4): #Makes the background a gradiant
            canvas.create_rectangle(0,mode.height*i/40,mode.width,\
                 mode.height, fill="gray"+str(40-i), outline="gray"+str(40-i))
        for block in range(len(mode.landBlocks)):
            mode.landBlocks[block].draw(canvas, mode)
        if mode.gameOver==False:
            mode.orderedDrawing(canvas)
            canvas.create_text(mode.width/2, mode.height/4, text=mode.message, \
                fill="white", font=f'Bahnschrift {mode.width//15} bold')
        else:
            if mode.clearObstacles()!=True:
                mode.player.drawDeathSequence(canvas, mode.clearObstacles(),\
                     mode, mode.deathCounter)
            elif mode.isOnTop()==False:
                mode.player.drawDeathSequence(canvas, "fall", mode,\
                     mode.deathCounter)
    def orderedDrawing(mode, canvas): #Draws it differently if player passed
        if len(mode.obstacles)==0:
            mode.player.drawPlayer(mode, canvas)
        else:
            for key in mode.obstacles:
                obstacle=mode.obstacles[key]
                if obstacle.cleared==True:
                    mode.player.drawPlayer(mode, canvas)
                    obstacle.draw(canvas, mode)
                elif obstacle.cleared==False:
                    obstacle.draw(canvas,mode)
                    mode.player.drawPlayer(mode, canvas)
class Obstacles(object): #will have more subclasses later
    def __init__(self, cx, cy, cz, mode):
        self.cx=cx
        self.cy=cy
        self.cz=cz
        self.apparentcx=self.cx
        self.apparentcy=self.cy
        self.cleared=False
        self.type=None
    def __eq__(self, other):
        if isinstance(other, Obstacles):
            return ((self.cx==other.cx) and (self.cy==other.cy) and \
                (self.cz==self.cz) and (self.cleared==other.cleared)\
                     and (self.type==other.type))
    def __hash__(self):
        return hash(self.getHashables())
    def getHashables(self):
        return (self.cx, self.cy, self.cz, self.cleared, self.type)
    def draw(self, canvas, mode):
        pass
class LaserGrid(Obstacles): #Will work on this after image is drawn
    def __init__(self, cx, cy, cz, mode, view, key, dict):
        super().__init__(cx, cy, cz, mode)
        self.key=key
        image="LaserGrid.png"
        sideImage=mode.loadImage("laserGridSide.png")
        self.type="LaserGrid"
        self.frontImage=mode.loadImage(image)
        self.sideImage=mode.scaleImage(sideImage, 1/2)
        self.depth=20
        self.width=100
        self.height=75
        self.initview=view
        if self.initview=="front":
            self.view=self.frontImage
            self.x0=self.cx-self.width/2
            self.x1=self.cx+self.width/2
            self.y0=self.cy-self.depth/2
            self.y1=self.cy+self.depth/2
            self.apparentx0=self.x0
            self.apparentx1=self.x1
            self.apparenty0=self.y0
            self.apparenty1=self.y1
        elif self.initview=="side":
            self.view=self.sideImage
            self.x0=self.cx-self.depth/2
            self.x1=self.cx+self.depth/2
            self.y0=self.cy-self.width/2
            self.y1=self.cy+self.width/2
            self.apparentx0=self.x0
            self.apparentx1=self.x1
            self.apparenty0=self.y0
            self.apparenty1=self.y1
        dict[key]=self
    def draw(self, canvas, mode):
        vanishingpt=mode.vanishingpoint
        ratio=(mode.width/2)/(mode.height-vanishingpt)
        yMap=vanishingpt+(mode.height-120-vanishingpt)*(2/3)**\
            ((self.apparentcy-mode.player.apparentY)/100) #For 2.5D graphics purposes
            #120 is coordinate of player
        leftMap=mode.width/2+(ratio*(yMap-vanishingpt)*(self.apparentx0-\
            mode.player.apparentX))/100
        rightMap=mode.width/2+(ratio*(yMap-vanishingpt)*(self.apparentx1-\
            mode.player.apparentX))/100
        scaleAtPoint=abs(rightMap-leftMap)
        pic = self.view
        x, y=pic.size
        if scaleAtPoint<5: #To stop the height, width must be >0 exception
            return
        else:
            scale=scaleAtPoint/x
        pic = pic.convert(mode="RGB")
        pic.thumbnail((round(pic.width*scale), round(pic.height*scale)))
        picx, picy=pic.size
        canvas.create_image(mode.width/2+(ratio*(yMap-vanishingpt)*\
            ((self.apparentx0+self.apparentx1)/2-mode.player.apparentX)/100),\
                 yMap-picy/2, image=ImageTk.PhotoImage(pic))
class Spikes(Obstacles):
    def __init__(self, cx, cy, cz, mode, view, key, dict):
        super().__init__(cx, cy, cz, mode)
        image="Spikes.png"
        self.type="Spikes"
        self.frontImage=mode.loadImage(image)
        self.sideImage=mode.loadImage(image)
        self.depth=100
        self.width=100
        self.height=100
        self.initview=view
        self.view=self.frontImage
        self.x0=self.cx-self.width/2
        self.x1=self.cx+self.width/2
        self.y0=self.cy-self.depth/2
        self.y1=self.cy+self.depth/2
        self.apparentx0=self.x0
        self.apparentx1=self.x1
        self.apparenty0=self.y0
        self.apparenty1=self.y1
        dict[key]=self
    def draw(self, canvas, mode):
        vanishingpt=mode.vanishingpoint
        ratio=(mode.width/2)/(mode.height-vanishingpt)
        yMap=vanishingpt+(mode.height-120-vanishingpt-self.height)*(2/3)**\
            ((self.apparentcy-mode.player.apparentY)/100) #For 2.5D graphics purposes
            #120 is coordinate of player
        leftMap=mode.width/2+(ratio*(yMap-vanishingpt)*(self.apparentx0-\
            mode.player.apparentX))/100
        rightMap=mode.width/2+(ratio*(yMap-vanishingpt)*(self.apparentx1-\
            mode.player.apparentX))/100
        scaleAtPoint=abs(rightMap-leftMap)
        pic = self.view
        x, y=pic.size
        if scaleAtPoint<5: #To stop the height, width must be >0 exception
            return
        else:
            scale=scaleAtPoint/x
        pic = pic.convert(mode="RGB")
        pic.thumbnail((round(pic.width*scale), round(pic.height*scale)))
        picx, picy=pic.size
        canvas.create_image(mode.width/2+(ratio*(yMap-vanishingpt)*\
            ((self.apparentx0+self.apparentx1)/2-mode.player.apparentX)/100),\
                 yMap-picy/2, image=ImageTk.PhotoImage(pic))
class landMass(object):
    def __init__(self,x0, x1, y0, y1, dict, key):
        self.x0=x0 #The true coordinates on a real map
        self.x1=x1 
        self.y0=y0
        self.y1=y1
        self.key=key
        self.apparentX0=self.x0 #The "Apparent" coordinates, which is used for 
        self.apparentX1=self.x1 #drawing
        self.apparentY0=self.y0
        self.apparentY1=self.y1
        self.color="gray"
        self.inverse="white"
        self.fill=self.color
        dict[key]=self
    def __eq__(self, other):
        return isinstance(other, landMass) and self.x0==other.x0 and \
            self.x1==other.x1 and self.y0==other.y0 and self.y1==other.y1 and \
                self.key==other.key
    def __hash__(self):
        return hash(self.getHashables())
    def getHashables(self):
        return (self.x0, self.x1, self.y0, self.y1, self.key)
    def onTop(self, mode):
        return (((self.y0<=mode.player.y<=self.y1) or \
                (self.y0>=mode.player.y>=self.y1)) and\
                     (self.x0<=mode.player.x<=self.x1))
    def draw(self, canvas, mode): #Draws Trapazoid
        #Takes each coordinate given (assumes that the terrain is rectangular)
        #and based on distance to the player, finds a point between the player 
        #and the vanishingpt to place the coordinate.Such a mapping is isometric
        vanishingpt=mode.vanishingpoint #As defined in appStarted
        ratio=(mode.width/2)/(mode.height-vanishingpt) 
        #^calculates 1/m, m being slope
        closeEdgeMap=vanishingpt+(mode.height-120-vanishingpt)*(2/3)**\
            ((self.apparentY0-mode.player.apparentY)/100) #120 is coordintate of player
        farEdgeMap=vanishingpt+(mode.height-120-vanishingpt)*(2/3)**\
            ((self.apparentY1-mode.player.apparentY)/100) #100 is random
        closeEdgeLeftMap=mode.width/2+ratio*(closeEdgeMap-vanishingpt)*\
            (self.apparentX0-mode.player.apparentX)/100
        closeEdgeRightMap=mode.width/2+ratio*(closeEdgeMap-vanishingpt)*\
            (self.apparentX1-mode.player.apparentX)/100
        farEdgeLeftMap=mode.width/2+ratio*(farEdgeMap-vanishingpt)*\
            (self.apparentX0-mode.player.apparentX)/100
        farEdgeRightMap=mode.width/2+ratio*(farEdgeMap-vanishingpt)*\
            (self.apparentX1-mode.player.apparentX)/100
        canvas.create_polygon(closeEdgeLeftMap, closeEdgeMap, \
        closeEdgeRightMap, closeEdgeMap, farEdgeRightMap,\
             farEdgeMap, farEdgeLeftMap, farEdgeMap, fill=self.fill)
class StartingBlock(landMass):
    def __init__(self,x0, x1, y0, y1, dict, key):
        super().__init__(x0, x1, y0, y1, dict, key)
        self.color="blue"
class EndingBlock(landMass):
    def __init__(self,x0, x1, y0, y1, dict, key):
        super().__init__(x0, x1, y0, y1, dict, key)
class Player(object):
    def __init__(self,x,y,z,R,D,J, mode):
        self.x=x
        self.y=y
        self.z=z
        self.renderX=0
        self.apparentX=self.x
        self.apparentY=self.y
        self.dir=0
        self.runSprite=R
        self.duckSprite=D
        self.jumpSprite=J
        deathFallImage=mode.loadImage("Falling to your Death.png")
        self.fallDeath=mode.packSprite(deathFallImage, 5)
        laserGridDeath=mode.loadImage("LaserGridDeath.png")
        self.laserGridDeath=mode.packSprite(laserGridDeath, 1)
        self.runWidth, self.runHeight, self.runDepth=\
            self.getRad(self.runSprite, mode) #Dimensions for player positions
        self.duckWidth, self.duckHeight, self.duckDepth=\
            self.getRad(self.duckSprite, mode)
        self.jumpWidth, self.jumpHeight, self.jumpDepth=\
            self.getRad(self.jumpSprite, mode)
        self.width,self.height, self.depth=\
            self.runWidth, self.runHeight, self.runDepth
        self.mode="run" #Modes are run, duck, and jump
        self.supported=True
        self.upv=0 #Current vertical velocity
    def turnLeft(self, mode):
        self.apparentX, self.apparentY=self.apparentY, -self.apparentX
        self.dir=(self.dir+1)%4
        for key in range(len(mode.landBlocks)):
            block=mode.landBlocks[key]
            block.apparentX0, block.apparentX1, block.apparentY0,\
            block.apparentY1=block.apparentY0, block.apparentY1,\
                    -block.apparentX1, -block.apparentX0
        #Note: This is linear algebra. Please recognize the amount of work \
        #I put into this
        for key in mode.obstacles:
            obstacle=mode.obstacles[key]
            obstacle.apparentx0, obstacle.apparentx1, obstacle.apparenty0,\
            obstacle.apparenty1=obstacle.apparenty0, obstacle.apparenty1,\
                    -obstacle.apparentx1, -obstacle.apparentx0
            obstacle.apparentcx, obstacle.apparentcy=obstacle.apparentcy, \
                -obstacle.apparentcx
            if obstacle.initview=="front":
                obstacle.view=obstacle.sideImage
                obstacle.initview="side"
            elif obstacle.initview=="side":
                obstacle.view=obstacle.frontImage
                obstacle.initview="front"
    def turnRight(self, mode): #works similiarly to turnLeft
        self.apparentX, self.apparentY=-self.apparentY, self.apparentX
        self.dir=(self.dir-1)%4
        for key in range(len(mode.landBlocks)):
            block=mode.landBlocks[key]
            block.apparentX0, block.apparentX1, block.apparentY0, \
            block.apparentY1=-block.apparentY1,-block.apparentY0,\
                block.apparentX0, block.apparentX1
        for key in mode.obstacles:
            obstacle=mode.obstacles[key]
            obstacle.apparentx0, obstacle.apparentx1, obstacle.apparenty0, \
                obstacle.apparenty1=-obstacle.apparenty1,-obstacle.apparenty0, \
                    obstacle.apparentx0, obstacle.apparentx1
            obstacle.apparentcx, obstacle.apparentcy=-obstacle.apparentcy,\
                 obstacle.apparentcx
            if obstacle.initview=="front":
                 obstacle.view=obstacle.sideImage
                 obstacle.initview="side"
            elif obstacle.initview=="side":
                 obstacle.view=obstacle.frontImage
                 obstacle.initview="front"
    def jump(self, ground,g, vi): #Is basically just physics
        if self.supported==True: #If you are on a platform
            self.supported=False #You're leaving the platform
            self.mode="jump" 
            self.upv+=vi #adds upward velocity by initial velocity
            self.z+=self.upv #adds the velocity to vertical position
            self.width,self.height, self.depth=self.jumpWidth, self.jumpHeight,\
                 self.jumpDepth #reassign dimensions to jump sprite
    def duck(self): #Changes player dimensions 
        if self.mode!="duck":
            self.mode="duck"
            self.width,self.height, self.depth=self.duckWidth, self.duckHeight,\
                 self.duckDepth
    def getRad(self, L, mode): #Gets the dimensions of the sprite images
        if len(L)==0:
            return None
        else: #Returns the "radius" of player sprite
            width, height=L[0].size
            return width/2, height/2, height/4 
    def drawPlayer(self, mode, canvas):
        x,z=self.renderX, self.z
        #uses a different image for running, jumping, and ducking
        if self.mode=="run":
            canvas.create_image(mode.width/2+x,mode.height-z-100-110, \
            image=ImageTk.PhotoImage(mode.runSprites[mode.runCounter%4]))
        elif self.mode=="jump":
            canvas.create_image(mode.width/2+x, mode.height-z-100-110, \
                image=ImageTk.PhotoImage(mode.jumpSprites[mode.runCounter%2]))
        elif self.mode=="duck":
            canvas.create_image(mode.width/2+x, mode.height-z-100-110, \
                image=ImageTk.PhotoImage(mode.duckSprites[0]))
            #^Numbers: the canvas offset plus a quarter of the size of the image
    def drawDeathSequence(self, canvas, methodOfDeath, mode, counter):
        x,z=self.renderX, self.z
        if isinstance(methodOfDeath, str):
            if methodOfDeath=="fall":
                if counter<5:
                    canvas.create_image(mode.width/2+x,mode.height-z-100-110, \
                        image=ImageTk.PhotoImage(self.fallDeath[counter]))
        elif isinstance(methodOfDeath, LaserGrid):
            canvas.create_image(mode.width/2+x,mode.height-z-100-110, \
                image=ImageTk.PhotoImage(self.laserGridDeath[0]))
        elif isinstance(methodOfDeath, Spike):
            canvas.create_image(mode.width/2+x,mode.height-z-100-110, \
             image=ImageTk.PhotoImage(self.duckSprite[0])) #Cutting corners

            

#class MyMusic(Thread): 
 #   def __init__(self, fileName):
  #      self.fileName=fileName
   #     self.waveform=wave.open(fileName)
    #    self.p=pyaudio.Pyaudio()
     #   self.stream=self.p.open()

