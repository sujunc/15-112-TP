import wave
#from Pyaudio import *
from cmu_112_graphics import * #taken from course website
from tkinter import *
from PIL import Image
import math
from GameMode import *
from SplashScreenMode import *

class GameOverMode(Mode):
    def appStarted(mode):
        pass
    def keyPressed(mode, event):
        mode.app.gameMode=GameMode()
        #mode.app.tutorialMode=TutorialMode()
        if event.key=="Space":
            mode.app.setActiveMode(mode.app.gameMode)
        if event.key=="r":
            mode.app.setActiveMode(mode.app.splashScreenMode)
    def redrawAll(mode, canvas):
        if mode.app.gameWon==True:
            canvas.create_rectangle(0,0, mode.width, mode.height, fill="cyan")
            canvas.create_text(mode.width/2, mode.height/5, text="Superb!", \
                font=f'modern {int(mode.width/10)} bold italic')
            canvas.create_text(mode.width/3, mode.height/3, \
                text=f'Your Score: {mode.app.score}', \
                    font=f"modern {int(mode.width/30)} bold")
        else:
            canvas.create_rectangle(0,0, mode.width, mode.height, \
                fill="violetred")
            canvas.create_text(mode.width/2, mode.height/4, text="A Nice Try",\
                font=f'modern {int(mode.width/10)} bold italic',fill="white")
            canvas.create_text(mode.width/3, mode.height/3, \
                text=f'Your Score: {mode.app.score}', \
                    font=f"modern {int(mode.width/30)} bold")
        