import wave
#from playsound import playsound
from cmu_112_graphics import * #taken from course website
from SplashScreenMode import *
from tkinter import *
from PIL import Image
import math
from SplashScreenMode import *


class LoadFileMode(Mode):
    def appStarted(mode):
        mode.imageEyesOpen=mode.loadImage("LoadFileImageEyesOpen.png")
        mode.imageEyesClosed=mode.loadImage("LoadFileImageEyesClosed.png")
        mode.image=mode.imageEyesOpen
        mode.popup=False
        mode.counter=0
        mode.songsInFolder=mode.findAllSongs()
        mode.buttonsMade=set()
        mode.buttonsInPopup=set()
        mode.X=Button(mode.width/2+mode.width/6-mode.width/36, mode.height/2-\
            mode.height/8, mode.width/2+mode.width/6, \
                mode.height/2-mode.height/8+mode.width/36, "red", "rectangle",\
                    "X", mode.buttonsInPopup)
        mode.ok=Button(mode.width/2-mode.width/8, mode.height/2+mode.height/12,\
             mode.width/2+mode.width/8, mode.height/2+mode.height/9,"gray",\
                "rectangle", "OK", mode.buttonsInPopup)
        mode.app.gameMusic=""
        mode.blankSlot=Button(mode.width/3, mode.height/2, mode.width*2/3, \
            mode.height/2+mode.height/6, "gray", "rectangle",\
                 "Path to music file: ", mode.buttonsMade) #Upload button
        mode.loadButton=Button(mode.width/3, mode.height/2+mode.height/5, \
            mode.width*2/3, mode.height/2+mode.height*2/5, "purple","rectangle",\
                "Begin", mode.buttonsMade) #Begin game
        mode.backButton=(Button(mode.width/12, mode.height/12, mode.width/6,\
             mode.height/6, "black", "rectangle", "Back", mode.buttonsMade))
             #Goes back to splash
    def timerFired(mode):
        mode.counter+=1
        if mode.counter%10==0:
            mode.image=mode.imageEyesClosed
        else: mode.image=mode.imageEyesOpen
    def mousePressed(mode, event):
        for button in mode.buttonsMade:
            if button.x0<event.x<button.x1 and button.y0<event.y<button.y1 and \
                mode.popup==False:
                if button==mode.blankSlot:
                    userInput=mode.getUserInput("Song:")
                    if userInput!=None:
                        mode.app.gameMusic="Music/"+userInput+".wav"
                    if mode.app.gameMusic!=None:#Displays song on screen
                        button.text=f'Path to music file: {userInput}'
                elif button==mode.loadButton and mode.app.gameMusic!="" and\
                    mode.app.gameMusic!=None:
                    if mode.app.gameMusic in mode.songsInFolder: 
                        #Checks if file exists
                        mode.app.setActiveMode(mode.app.gameMode)
                    else: mode.popup=True
                elif button==mode.backButton:
                    mode.app.setActiveMode(mode.app.splashScreenMode)
        if mode.popup==True:
            for button in mode.buttonsInPopup:
                if button.x0<event.x<button.x1 and button.y0<event.y<button.y1:
                    mode.popup=False 
    def findAllSongs(mode): #Finds all song files in folder so it doesn't crash
        songFiles=[]
        for fileName in os.listdir("Music"):
            if os.path.isfile("Music/"+fileName) and fileName.endswith(".wav"):
                songFiles+=["Music/"+fileName]
        return songFiles
    def redrawAll(mode, canvas): #Positions are determined by trial & error
        canvas.create_image(mode.width*5/9, mode.height*3/7, \
            image=ImageTk.PhotoImage(mode.image))
        for button in mode.buttonsMade:
            button.drawButton(canvas)
        if mode.popup==True:
            mode.drawPopup(canvas)
    def drawPopup(mode, canvas):
        canvas.create_rectangle(mode.width/2-mode.width/6, \
            mode.height/2-mode.height/8, mode.width/2+mode.width/6, \
                mode.height/2+mode.height/8, fill="white")
        canvas.create_text(mode.width/2, mode.height/2, \
            text="Sorry, File Not Found")
        for button in mode.buttonsInPopup:
            button.drawButton(canvas)
