import sys
import wave
from cmu_112_graphics import * #taken from 
#http://www.cs.cmu.edu/~112/notes/cmu_112_graphics.py
from tkinter import *
from PIL import Image
import math
from SplashScreenMode import *
from GameMode import *
from LoadFileMode import *
from GameOverMode import *

class Run(ModalApp):
    def appStarted(app):
        app.splashScreenMode=SplashScreenMode()
        #app.tutorialMode=TutorialMode()
        app.loadFileMode=LoadFileMode()
        app.gameMode=GameMode()
        app.setActiveMode(app.splashScreenMode)
        app.gameMusic=""
        app.gameOverMode=GameOverMode()
        app.gameWon=False
        app.score=0
        app.platformsCrossed=[]
A=Run(width=600, height=600)