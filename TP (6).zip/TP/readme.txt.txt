A short description of the project's name and what it does:
Music Run: It generates a obstacle course based on a song's beats and the player runs across it. 

How to run the project. For example, which file the user should run in an editor. If your project uses data/source files, also describe how the user should set those up.
The user should open the Main file and run it. All music files should be in .wav format, and should be in the Music folder, should the user want to use their own files. 

Which libraries you're using that need to be installed. If you can include the library in the submission, that is preferred.
Libraries: Aubio for the sound processing, and pygame to play the sound. They should also have the 112 animation graphics framework.

A list of any shortcut commands that exist: None. 