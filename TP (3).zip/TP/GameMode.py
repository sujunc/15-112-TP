import sys
import wave
import pyaudio
from threading import *
from AubioBeatDetection import *
from cmu_112_graphics import * #Taken from course website
from tkinter import *
from PIL import Image
import math
print(f'{sys.executable} -m pip install pillow')
print(f'{sys.executable} -m pip install requests')

class GameMode(Mode):
    def appStarted(mode):
        mode.runImage=mode.loadImage("Running Sprite Sheet.png")
        mode.runSprites=mode.packSprite(mode.runImage,4)
        D=[] #Placeholders for the real thing, as the sprites aren't ready
        J=[]
        mode.player=Player(0,0,20, mode.runSprites, D, J, mode)
        mode.runCounter=0
        mode.vanishingpoint=mode.height/3 #Arbitrary reference pt:2.5d graphics
        mode.gameOver=False
        mode.timer=0 #Tells how long to duck for
        mode.landBlocks=set()
        mode.musicLoaded=False
        mode.score=0
        mode.obstacles=set()
        if mode.app.gameMusic!="":
            mode.music=mode.app.gameMusic
            mode.musicLoaded=True
        else: mode.musicLoaded=False
        mode.beats=detectBeat(mode.music)
        mode.tempo=mode.beats[1]-mode.beats[0]
        mode.vi=20
        mode.g=10
        mode.speed=10
        mode.i=1
        if mode.vi/mode.g>2:
            mode.i=int(mode.vi/mode.g*2)
        #Code commented out is a little buggy, 
        #for beat in range(0,len(mode.beats),mode.i): 
         #   if beat==0:
          #      landMass(-300,300,0,1000*mode.i+mode.beats[0]*mode.speed,\
           #         mode.landBlocks)
           # else: landMass(-300, 300, \
            #    1000*mode.i+mode.beats[beat-1]*mode.speed+\
             #       mode.tempo*mode.speed/(8*mode.i),\
              #  1000*mode.i+mode.beats[beat]*mode.speed, mode.landBlocks)
        landMass(-300,300, 0, 300, mode.landBlocks) #For testing
        landMass(-300, 300, 305, 600, mode.landBlocks)
    def packSprite(mode, image, frames):
        spriteList=[]
        width, height=image.size
        hr=110/height #Music Theory jokes
        scale=mode.scaleImage(image, hr) #Scales the image to be 110 pxls
        w, h=scale.size
        for i in range(frames):
            sprite=scale.crop((i*w/frames, 0, (i+1)*w/frames, h))
            spriteList+=[sprite] #Puts spritesheet into list
        return spriteList
    def keyPressed(mode, event):
        if mode.gameOver==False:
            if event.key=="Space":
                mode.player.jump(0, mode.g, mode.vi) #Does physics on player
            elif event.key=="a":
                mode.player.x-=5
            elif event.key=="d":
                mode.player.x+=5
            elif event.key=="s":
                mode.player.duck()
    def clearObstacles(mode): #Checks if clears obstacles based on location, etc
        for obstacle in mode.obstacles:
            if (((obstacle.cx-obstacle.width/2<mode.player.x-mode.player.width<\
                obstacle.cx+obstacle.width/2) or (obstacle.cx-obstacle.width/2\
                <mode.player.x+mode.player.width<obstacle.cx+obstacle.width/2))\
                     and \
                ((obstacle.cy-obstacle.depth/2<mode.player.y-mode.player.depth\
                <obstacle.cy+obstacle.depth/2) or (obstacle.cy-obstacle.depth/2\
                <mode.player.y+mode.player.depth<obstacle.cy+obstacle.depth/2))\
                     and \
                ((obstacle.cz<mode.player.z-mode.player.height<\
                    mode.cz+obstacle.height) or \
                    (obstacle.cz<mode.player.z+mode.player.z\
                        <mode.cz+obstacle.height))):
                return True
        return False
    def timerFired(mode):
        if mode.gameOver==False:
            mode.player.y+=mode.speed #Increments by steady run speed
            mode.score+=int(mode.speed/2) #Adds int score to player.
            mode.runCounter+=1 #Loops through sprite
            if mode.clearObstacles()==False:
                mode.gameOver=True
            if mode.musicLoaded==False:
                mode.musicLoaded==None
            if mode.player.z<= 20 and not mode.isOnTop(): #Accounts for edge cs
                mode.player.supported=False
                mode.gameOver=True
            if mode.player.ducking==True: 
                mode.timer+=1
                if mode.timer%20==0:
                    mode.player.ducking=False
                    mode.player.mode="run"
                    mode.player.width, mode.player.height, mode.player.depth=\
                        mode.player.runWidth, mode.player.runHeight,\
                             mode.player.runDepth
            elif mode.player.ducking==False:
                if mode.player.z>20:
                    mode.player.upv-=mode.g
                    mode.player.z+=mode.player.upv
                elif mode.player.z<20:
                    #If the player's y falls inside the map's y, we know that 
                    #the player is on solid ground, so we can change the is 
                    #supported to True.
                    if mode.isOnTop():
                        mode.player.supported=True
                        mode.player.z=20
                        mode.player.upv=0
                else: 
                    if mode.isOnTop():
                        mode.player.supported=True
    def isOnTop(mode):
        for block in mode.landBlocks: #Checks if player is supported
            if ((block.y0<mode.player.y<block.y1) or \
                (block.y0>mode.player.y>block.y1)) and\
                     (block.x0<mode.player.x<block.x1):
                return True
        return False
    def redrawAll(mode, canvas):
        for i in range(0,40, 4): #Makes the background a gradiant
            canvas.create_rectangle(0,mode.height*i/40,mode.width,\
                 mode.height, fill="gray"+str(40-i), outline="gray"+str(40-i))
        for block in mode.landBlocks:
            block.draw(canvas, mode)
        x,z=mode.player.x, mode.player.z
        canvas.create_image(mode.width/2+x,mode.height-z-100-27, \
            image=ImageTk.PhotoImage(mode.runSprites[mode.runCounter%4]))
            #^Numbers: the canvas offset plus a quarter of the size of the image
        canvas.create_rectangle(0,0,mode.width/5,mode.height/8,fill="slategray")
class Obstacles(object): #will have more subclasses later
    def __init__(self, cx, cy, cz, width, depth, height, set):
        self.cx=cx
        self.cy=cy
        self.cz=cz
        self.width=width
        self.depth=depth
        self.height=height
        set.add(self)
class LaserGrid(Obstacles): #Will work on this after image is drawn
    def __init__(self, cx, cy, cz, width, depth, height, set):
        super().__init__(cx, cy, cz, width, depth, height, set)
        self.image=#Yet to be drawn
class landMass(object):
    def __init__(self, x0,x1,y0, y1, set):
        self.x0=x0
        self.x1=x1
        self.y0=y0
        self.y1=y1
        set.add(self)
    def __eq__(self, other):
        return isinstance(other, landMass) and self.x0==other.x0 and \
            self.x1==other.x1 and self.y0==other.y0 and self.y1==other.y1
    def __hash__(self):
        return hash((self.x0, self.x1, self.y0, self.y1))
    def draw(self, canvas, mode):
        vanishingpt=mode.vanishingpoint
        ratio=(mode.width/2)/(mode.height-vanishingpt)
        closeEdgeMap=vanishingpt+(mode.height-120-vanishingpt)*(2/3)**\
            ((self.y0-mode.player.y)/100) #120 is coordintate of player
        farEdgeMap=vanishingpt+(mode.height-120-vanishingpt)*(2/3)**\
            ((self.y1-mode.player.y)/100) #100 is random
        closeEdgeLeftMap=mode.width/2-ratio*(closeEdgeMap-vanishingpt)
        closeEdgeRightMap=mode.width/2+ratio*(closeEdgeMap-vanishingpt)
        farEdgeLeftMap=mode.width/2-ratio*(farEdgeMap-vanishingpt)
        farEdgeRightMap=mode.width/2+ratio*(farEdgeMap-vanishingpt)
        canvas.create_polygon(closeEdgeLeftMap, closeEdgeMap, \
        closeEdgeRightMap, closeEdgeMap, farEdgeRightMap,\
             farEdgeMap, farEdgeLeftMap, \
                 farEdgeMap, fill="gray")
class Player(object):
    def __init__(self,x,y,z,R,D,J, mode):
        self.x=x
        self.y=y
        self.z=z
        self.runSprite=R
        self.duckSprite=D
        self.jumpSprite=J
        self.runWidth, self.runHeight, self.runDepth=\
            self.getRad(self.runSprite, mode) #Dimensions for player positions
        self.duckWidth, self.duckHeight, self.duckDepth=\
            self.getRad(self.duckSprite, mode)
        self.jumpWidth, self.jumpHeight, self.jumpDepth=\
            self.getRad(self.jumpSprite, mode)
        self.width,self.height, self.depth=\
            self.runWidth, self.runHeight, self.runDepth
        self.mode="run" #Modes are run, duck, and jump
        self.supported=True
        self.upv=0 #Current vertical velocity
        self.ducking=False
    def jump(self, ground,g, vi): #Is basically just physics
        if self.supported==True:
            self.supported=False
            self.mode="jump"
            self.upv+=vi
            self.z+=self.upv
            self.width,self.height, self.depth=self.jumpWidth, self.jumpHeight,\
                 self.jumpDepth
    def duck(self): #Changes player dimensions 
        if self.ducking==False:
            self.mode="duck"
            self.ducking=True
            self.width,self.height, self.depth=self.duckWidth, self.duckHeight,\
                 self.duckDepth
    def getRad(self, L, mode): #Gets the dimensions of the sprite images
        if len(L)==0:
            return None
        else: 
            width, height=L[0].size
            return width/2, height/2, height/4
            

#class MyMusic(Thread): 
 #   def __init__(self, fileName):
  #      self.fileName=fileName
   #     self.waveform=wave.open(fileName)
    #    self.p=pyaudio.Pyaudio()
     #   self.stream=self.p.open()

