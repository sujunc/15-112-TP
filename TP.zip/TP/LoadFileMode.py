import sys
import wave
from playsound import playsound
from cmu_112_graphics import * #taken from course website
from SplashScreenMode import *
from tkinter import *
from PIL import Image
import math
from SplashScreenMode import *
print(f'{sys.executable} -m pip install pillow')
print(f'{sys.executable} -m pip install requests')

class LoadFileMode(Mode):
    def appStarted(mode):
        mode.imageEyesOpen=mode.loadImage("LoadFileImageEyesOpen.png")
        mode.imageEyesClosed=mode.loadImage("LoadFileImageEyesClosed.png")
        mode.image=mode.imageEyesOpen
        mode.popup=False
        mode.counter=0
        mode.buttonsMade=set()
        mode.app.gameMusic=""
        mode.blankSlot=Button(mode.width/3, mode.height/2, mode.width*2/3, \
            mode.height/2+mode.height/6, "white", "rectangle",\
                 "Path to music file: ", mode.buttonsMade) #Upload button
        mode.loadButton=Button(mode.width/3, mode.height/2+mode.height/5, \
            mode.width*2/3, mode.height/2+mode.height*2/5, "white","rectangle",\
                "Begin", mode.buttonsMade) #Begin game
        mode.backButton=(Button(mode.width/12, mode.height/12, mode.width/6,\
             mode.height/6, "white", "rectangle", "Back", mode.buttonsMade))
             #Goes back to splash
    def timerFired(mode):
        mode.counter+=1
        if mode.counter%10==0:
            mode.image=mode.imageEyesClosed
        else: mode.image=mode.imageEyesOpen
    def mousePressed(mode, event):
        for button in mode.buttonsMade:
            if button.shape=="rectangle":
                if button.x0<event.x<button.x1 and button.y0<event.y<button.y1:
                    if button==mode.blankSlot:
                        userInput=mode.getUserInput("Song:")
                        mode.app.gameMusic="Music/"+userInput
                        if mode.app.gameMusic!=None:#Displays song on screen
                            button.text=\
                                f'Path to music file: {userInput}'
                    elif button==mode.loadButton and mode.app.gameMusic!="" and\
                        mode.app.gameMusic!=None:
                        if os.path.isfile(mode.app.gameMusic) and \
                            mode.app.gameMusic.endswith(".wav"):
                            #Checks file type
                            mode.app.setActiveMode(mode.app.gameMode)
                            #So it doesn't crash
                    elif button==mode.backButton:
                        mode.app.setActiveMode(mode.app.splashScreenMode)
            elif button.shape=="oval": #Will implement later
                cx, cy=(x0+x1)/2, (y0+y1)/2
                if math.sqrt((event.x-cx)**2+(event.y-cy)**2):
                    button.color="Green"
    def findAllSongs(mode): ####Choose to implement this later
        songFiles=[]
        for fileName in os.listdir("Music"):
            if os.path.isfile("Music/"+fileName) and fileName.endswith(".wav"):
                songFiles+=["Music/"+fileName]
        return songFiles
    def redrawAll(mode, canvas): #Positions are determined by trial & error
        canvas.create_image(mode.width*5/9, mode.height*3/7, \
            image=ImageTk.PhotoImage(mode.image))
        for button in mode.buttonsMade:
            button.drawButton(canvas)